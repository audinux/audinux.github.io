#include "header.h"
int main(int argc, char **argv) {
  func0();
  return 0;
}
