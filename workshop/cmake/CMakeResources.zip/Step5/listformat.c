#include <stdio.h>

#include "config.h"

int main() {
  printf("The following image format has been detected: ");
#ifdef HAVE_PNG
  printf(",PNG ");
#endif
#ifdef HAVE_TIFF
  printf(",TIFF ");
#endif
#ifdef HAVE_JPEG
  printf(",JPEG ");
#endif
  printf("\n");
  return 0;
}
