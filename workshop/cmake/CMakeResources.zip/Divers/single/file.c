#include<stdio.h>
#include"header.h"

int func0() { return 0; }
