#include "mylibrary.h"

int main() {
  print_hello();
  return 0;
}

