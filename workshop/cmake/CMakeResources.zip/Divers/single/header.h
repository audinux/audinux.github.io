int func0();
