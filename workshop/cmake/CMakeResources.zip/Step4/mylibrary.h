#ifndef MYLIBRARY_H
#define MYLIBRARY_H

void print_hello();

#endif

