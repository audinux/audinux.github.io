
solution "Speedtest"
  configurations { "Debug", "Release"}
  location "buildpremake"

project "Speedtest"
  kind "ConsoleApp"
  language "C"
  location "buildpremake"
  files { "*.c", "*.h" }
