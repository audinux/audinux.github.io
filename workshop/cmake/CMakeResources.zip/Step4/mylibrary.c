#include <stdio.h>

void print_hello() {
  printf("Hello World !\n");
}

